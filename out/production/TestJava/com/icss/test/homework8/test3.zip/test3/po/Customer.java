package com.icss.test.homework8.test3.po;

/**
 * Created by 29185 on 2017/6/7.
 */
public class Customer {
    private String name;

    public void setName(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }
}
