package Quiz2.Kesa;

import java.util.Scanner;

/**
 * Created by 29185 on 2017/6/2.
 */
public class Switcher {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        System.out.println("请选择操作：1.加密\t2.解密");
        int check = in.nextInt();
        switch (check){
            case 1:
                System.out.println("请输入待加密的字符串：");
                String name = in.next();
                input(name);
                break;
            case 2:
                break;
        }


        input();
    }

    public static char[] input(String name){
        char [] contanier = new char[name.length()];
        for(int i = 0;i<name.length();i++){
            contanier[i] = name.charAt(i) ;
        }
        return contanier;
    }
}
