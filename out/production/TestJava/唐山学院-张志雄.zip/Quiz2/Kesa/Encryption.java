package Quiz2.Kesa;

/**
 * Created by 29185 on 2017/6/2.
 */
public class Encryption {
    public char[] out(char [] a){
        for (int i =0;i<a.length;i++){
            a[i] = int(a[i])+3;
        }
    }
}
