package com.icss.test.homework11.test2.po;

/**
 * Created by 29185 on 2017/6/14.
 */
public class GoodsInfo {
    private String goods_id;
    private String goods_name;
    private int type_id;

    public String getGoods_id() {
        return goods_id;
    }

    public void setGoods_id(String goods_id) {
        this.goods_id = goods_id;
    }

    public String getGoods_name() {
        return goods_name;
    }

    public void setGoods_name(String goods_name) {
        this.goods_name = goods_name;
    }

    public int getType_id() {
        return type_id;
    }

    public void setType_id(int type_id) {
        this.type_id = type_id;
    }
}
